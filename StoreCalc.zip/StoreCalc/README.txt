New for v0.24:
-Added alert dialog to confirm starting order over
-Added onClick method for popup item list to open expandable listview and "click" on selected item
-Fixed Issue for Preventing Spaces in create order edittext
-Added Edit button next to Starting Funds Amount and set protocol 
-Modified Edit Button background
-Modified Funds total layout background